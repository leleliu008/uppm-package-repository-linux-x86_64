echo "hello xmake!"
